# Shorts and Reels layout tests

Open video-benchmark/results/shorts_round2/comparison.html after extracting the complete archive.

Veo 3.1 Quality Official and Kling V4, four seconds each, native model-generated speech. Each has normal full vertical and lower-positioned presenter compositions using new synthetic reference stills.

Original native MP4s: video-benchmark/results/shorts_round2/full/ and lower/.
Exact 1080x1920 exports: video-benchmark/results/shorts_round2/exports/full/ and exports/lower/. Lower-layout exports have an opaque #101827 upper 960-pixel region for infographic compositing. Kling exports upscale native 720p; native AAC audio is copied unchanged.

Detailed prompts and authorization: video-benchmark/config/shorts-round2.json. References: video-benchmark/references/round2-full.png and round2-lower.png. Current actual costs, native/export metrics and manual scoring are in the results folder.

These are premium model candidates, not a proven best-model ranking. Lip sync, exact spoken wording and qualitative scores need playback review. No separate TTS, audio replacement or music generation was used.

Private task IDs, temporary result URLs and the shared spending ledger are excluded from this archive. The CLI blocks if completed public results exist without the original private ledger; do not regenerate to replace missing state. Use the existing cloud environment to resume live operations. No API key is included. The previous pilot media are in a separate earlier bundle.
